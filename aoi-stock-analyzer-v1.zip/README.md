# あおい株分析

チャート画像 + OpenAI Responses API + Web Search を使う個人用株分析PWA。

## Render
- Runtime: Node
- Build Command: `npm install`
- Start Command: `npm start`
- Environment Variable: `OPENAI_API_KEY`
- Optional: `OPENAI_MODEL=gpt-5.6`

APIキーはGitHubに保存しないでください。
