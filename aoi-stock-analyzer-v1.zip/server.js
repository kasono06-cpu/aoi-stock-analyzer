import express from "express";
import OpenAI from "openai";

const app = express();
app.use(express.json({ limit: "18mb" }));
app.use(express.static("public"));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const AOI_PROMPT = `
あなたは日本株の短期・中期分析を行う「あおい」です。
ユーザーが送った株価チャート画像と銘柄情報を読み、必要に応じてWeb検索を使って最新の決算・IR・ニュースを確認してください。

分析方針:
- 結論を最初に。曖昧なことは断定しない。
- 画像から読み取れない数値を捏造しない。
- チャートでは支持線・抵抗線・ローソク足・出来高・移動平均線・VWAP（見える場合）・MACD/RSI/ストキャス（見える場合）を確認。
- 短期では上位足の環境認識→意識される水平線/ネックライン→当日の反応→再反発/再反落の順で考える。
- 価格帯別出来高が見える場合は重要帯を確認。
- 2〜5営業日と約1か月を分けてシナリオ化する。
- Web検索を使った場合は、最新の決算、適時開示、資金調達、希薄化、業績修正、テーマ材料など株価に効くものを優先する。
- 投資助言の断定ではなく、条件付きシナリオとして示す。
- 日本語で、読みやすく簡潔に。ただし根拠は省かない。

必ずこの順番:
🎯 結論
📈 テクニカル
🏢 決算・IR・材料
💹 需給
🔥 上昇トリガー
⚠️ リスク
⏱ 2〜5日シナリオ
📅 約1か月シナリオ
💙 あおい判定

最後の「あおい判定」では
チャート / 需給 / ファンダ / 短期妙味 を各10点満点で示す。
`;

app.post("/api/analyze", async (req, res) => {
  try {
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: "OPENAI_API_KEY が設定されていません。" });
    }
    const { symbol = "", note = "", imageDataUrl, webSearch = true } = req.body || {};
    if (!imageDataUrl || !imageDataUrl.startsWith("data:image/")) {
      return res.status(400).json({ error: "チャート画像を選んでください。" });
    }

    const userText = `銘柄: ${symbol || "画像から判断（不明なら不明と書く）"}
追加メモ: ${note || "なし"}
このチャートを分析してください。`;

    const tools = webSearch ? [{ type: "web_search" }] : [];

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.6",
      store: false,
      tools,
      input: [
        { role: "developer", content: [{ type: "input_text", text: AOI_PROMPT }] },
        {
          role: "user",
          content: [
            { type: "input_text", text: userText },
            { type: "input_image", image_url: imageDataUrl, detail: "high" }
          ]
        }
      ]
    });

    res.json({ text: response.output_text || "分析結果を取得できませんでした。" });
  } catch (e) {
    console.error(e);
    const msg = e?.error?.message || e?.message || "分析中にエラーが発生しました。";
    res.status(500).json({ error: msg });
  }
});

app.get("/health", (_req, res) => res.json({ ok: true }));

const port = process.env.PORT || 10000;
app.listen(port, "0.0.0.0", () => console.log(`Aoi Stock Analyzer running on ${port}`));
